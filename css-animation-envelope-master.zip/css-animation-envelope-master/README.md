# 信封动效
![动效演示](animation-show.gif)
纯CSS实现一个信封打开动效

### B站视频链接
https://www.bilibili.com/video/BV1wW4y1p7iA/

### 欢迎关注
- B站、公众号、小红书：白泽小唐